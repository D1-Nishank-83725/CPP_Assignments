#include <iostream>
using namespace std;

class Servicing
{
private:
    string customerName;
    int vehicleNo;
    long int mobileNo;
    double totalBill;



public:
    void enterVehicleNo()
    {
        cout << "Enter Vehicle Number: ";
        cin >> vehicleNo;
    }

    // Making Function Virtual: Class becomes Abstract, now have to define it in Derived Class
    virtual void calculateTotalBill() = 0;

    //Getter Function to access totalBill as it will be inaccessible when inherited, becuase it is private
    int getTotalBill(){
        return totalBill;
    }

};



// Public Inheritance

class MaintainenceRepairing : public Servicing
{
    private:
        string partName;
        double partPrice;
        double labourCharge;
        double maintainenceRepairingTotalBill;
    
    public:
        void acceptDetails(){
            Servicing::enterVehicleNo();
            cout << "Enter the Vehicle Part to be Replaced: ";
            cin >> partName;
            cout << "Enter the Vehicle Part's Price :";
            cin >> partPrice;
            try{
                if (partPrice < 0)
                {
                    throw 1;
                }
            }
            catch(...){
                cout << "Please enter a Valid value for Vehicle Part's Price "<< endl;
            }
            
            cout << "Enter Labour Charge: ";
            cin >> labourCharge;
            try{
                if (labourCharge < 0)
                {
                    throw 1;
                }
            }
            catch(...){
                cout << "Please enter a Valid value for Labour Charge "<< endl;
            }

        }

        void addGST(){
            partPrice = partPrice + ((5*partPrice)/100);
            labourCharge = labourCharge + ((5*labourCharge)/100);
        }

        void calculateTotalBill(){
            addGST();
            maintainenceRepairingTotalBill = getTotalBill();
            maintainenceRepairingTotalBill = partPrice + labourCharge;
            cout << "Total Bill to Pay: " << maintainenceRepairingTotalBill;
        }

        
};

//Public Inheritance

class EngineOilChange : public Servicing
{
private:
    string oilName;
    double oilPrice;
    double engineOilChangeTotalBill;

public:
    void acceptDetails(){
        Servicing::enterVehicleNo();
        cout << "Enter the Oil Brand Name ";
            cin >> oilName;
            cout << "Enter the Oil's Price :";
            cin >> oilPrice;
            try{
                if (oilPrice < 0)
                {
                    throw 1;
                }
            }
            catch(...){
                cout << "Please enter a Valid Value for Oil's Price "<< endl;
            }
    }

    void addGST(){
        oilPrice = oilPrice + ((12*oilPrice)/100);
    }

    void calculateTotalBill(){
        addGST();
        engineOilChangeTotalBill = getTotalBill();
        engineOilChangeTotalBill = oilPrice;
        cout << "Total Bill to Pay: " << engineOilChangeTotalBill;

    }

};



int main()
{
    //Created objects as no specific instruction was given in the Question

    MaintainenceRepairing mr1;
    EngineOilChange eo1;

    int choice;

    do
    {
        // Menu - Driven Code

        cout << "\n0: EXIT "<< endl;
        cout << "1: Accept Details for Maintainence/Repairing " << endl;
        cout << "2: Calculate Total Bill for Maintainence/Repairing " << endl;
        cout << "3: Accept Details for Engine/Gear Oil Change " << endl;
        cout << "4: Calculate Total Bill for Engine/Gear Oil Change \n" << endl;

        cin >> choice;

        switch (choice)
        {
        case 0:
            cout << "Thank you for using the Program " << endl;
            break;

        case 1:
            mr1.acceptDetails();
            break;

        case 2:
            mr1.calculateTotalBill();
            break;

        case 3:
            eo1.acceptDetails();
            break;

        case 4:
            eo1.calculateTotalBill();
            break;
        
        default:
            cout << "Invalid Choice " << endl;
            break;
        }

    } while (choice != 0);
    

    return 0;
}
